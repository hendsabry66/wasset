<?php
return [
    'control'=>'التحكم',
    'show'=>'عرض',
    'edit'=>'تعديل',
    'delete'=>'حذف',
    'multiDelete'=>' حذف متعدد',
    'cancel'=>'الغاء',
    'save'=>'حفظ',
    'dashboard'=>'الرئيسية',

    'status'=>'الحالة',
    'active'=>'فعال ',
    'in_active'=>' غير فعال ',

    'name'=>'الاسم',
    'image'=>'الصورة',
    'order'=>'الترتيب',
    'title'=>'العنوان',
    'details'=>'التفاصيل ',
    'phone'=>'رقم الجوال ',
    'email'=>'البريد الالكتروني ',
    'password'=>'كلمة المرور  ',
    'roles'=>'الصلاحيات ',
    'communication'=>'وسيلة الاتصال  ',
    'latitude'=>'العرض ',
    'longitude'=>'الطول ',


    'cities'=>'المدن',
    'addCity'=>'اضافة مدينة',
    'editCity'=>'تعديل  مدينة',
    'city'=>'المدينة',
    'addNewCity'=>'اضافة مدينة جديدة',

    'ads'=>'المنشورات',
    'addAd'=>'اضافة منشور',
    'editAd'=>'تعديل منشور',
    'ad'=>'منشور',
    'addNewAd'=>'اضافة منشور جديدة',

    'banners'=>'الاعلانات',
    'addBanner'=>'اضافة اعلان',
    'banner'=>'اعلان',
    'addNewBanner'=>'اضافة اعلان جديدة',
    'editBanner'=>'تعديل اعلان ',

    'categories'=>'الاقسام',
    'addCategory'=>'اضافة قسم',
    'category'=>'القسم',
    'addNewCategory'=>'اضافة قسم جديدة',
    'editCategory'=>'تعديل القسم ',

    'countries'=>'الدول',
    'addCountry'=>'اضافة دولة',
    'editCountry'=>'تعديل دولة',
    'country'=>'الدول',
    'addNewCountry'=>'اضافة دولة جديدة',

    'pages'=>'الصفحات',
    'addPage'=>'اضافة صفحة',
    'editPage'=>'تعديل صفحة',
    'page'=>'الصفحة',
    'addNewPage'=>'اضافة صفحة جديدة',

    'users'=>'لاعضاء',
    'addUser'=>'اضافة عضو',
    'user'=>'عضو',
    'addNewUser'=>'اضافة عضو  جديدة',
    'editUser'=>'تعديل عضو  ',

    'roles'=>'الصلاحيات',
    'addRole'=>'اضافة صلاحيه',
    'role'=>'صلاحيه',
    'addNewRole'=>'اضافة صلاحيه  جديدة',
    'editRole'=>'تعديل صلاحيه  ',

    'contacts'=>' رسائل الاتصال بنا',
    'compliance'=>'   شكوي',
    'issue'=>'   مشكلة',
    'type'=>'   نوع',
    'sent'=>'   تم الارسال',
    'seen'=>'   تم الاطلاع',
    'replied'=>'   تم الرد',
    'settings'=>'    الاعدادات',

    'menue'=>'    القائمة',
    'choose'=>'   اختر',
    'subcategory'=>'   القسم الفرعي',
    'images'=>'    الصور',
    'user_type'=>'    نوع العضو',


];
