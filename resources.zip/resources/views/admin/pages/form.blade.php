<div class="row">
    <div class="form-group col-md-6 mb-2">
        <label for="projectinput4">@lang('admin.title')</label>
        <input type="text"  class="form-control" @if(isset($page)) value="{{$page->title}}" @endif placeholder="{{__('admin.title')}}" name="title">
    </div>
    <div class="form-group col-md-6 mb-2">
        <label for="projectinput4">@lang('admin.image')</label>
        <input type="file" name="image" class="form-control">
    </div>
    <div class="form-group col-md-6 mb-2">
        <label for="projectinput3">@lang('admin.status')</label>
        <select class="select2 form-control" name="status">

            <option value="active" @if(isset($page) && $page->status =="active") selected @endif >@lang('admin.active')</option>
            <option value="in_active" @if(isset($page) && $page->status =="in_active") selected @endif>@lang('admin.in_active')</option>

        </select>
    </div>
    <div class="form-group col-md-12 mb-2">
        <label for="projectinput4">@lang('admin.details')</label>
        <textarea name="details" id="tinymce">@if(isset($page)) {!! $page->details !!} @endif </textarea>
    </div>


</div>
