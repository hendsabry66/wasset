<label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
    <input type="checkbox" name="ids[]" class="checkboxes checkbox" value="{{ $id }}" form="bulk_delete_modal"/>
    <span></span>
</label>
