<?php

namespace App\Repositories;

use App\Models\Ad;
use App\Repositories\BaseRepository;

/**
 * Class AdRepository
 * @package App\Repositories
 * @version May 31, 2022, 8:46 pm UTC
*/

class AdRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        
    ];

    /**
     * Return searchable fields
     *
     * @return array
     */
    public function getFieldsSearchable()
    {
        return $this->fieldSearchable;
    }

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Ad::class;
    }
}
